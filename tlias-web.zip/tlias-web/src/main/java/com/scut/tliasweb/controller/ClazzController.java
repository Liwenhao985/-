package com.scut.tliasweb.controller;

import com.scut.tliasweb.anno.OperateLog;
import com.scut.tliasweb.pojo.Clazz;
import com.scut.tliasweb.pojo.Result;
import com.scut.tliasweb.service.ClazzService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RequestMapping("/clazzs")
@RestController
public class ClazzController {

    @Autowired
    private ClazzService clazzService;

    //分页查询
    @GetMapping
    public Result pageQuery(int page, int pageSize) {
        return Result.success(clazzService.pageQuery(page, pageSize));
    }

    //根据id删除班级
    @OperateLog
    @DeleteMapping("/{id}")
    public Result delete(@PathVariable Integer id) {
        clazzService.delete(id);
        return Result.success();
    }

    //添加班级
    @OperateLog
    @PostMapping
    public Result add(@RequestBody Clazz clazz) {
        clazzService.add(clazz);
        return Result.success();
    }

    //根据id查询班级
    @GetMapping("/{id}")
    public Result getById(@PathVariable Integer id) {
        return Result.success(clazzService.getById(id));
    }

    //修改班级信息
    @OperateLog
    @PutMapping
    public Result update(@RequestBody Clazz clazz) {
        clazzService.update(clazz);
        return Result.success();
    }

    //查询所有班级
    @GetMapping( "/list")
    public Result getAll() {
        return Result.success(clazzService.getAll());
    }
}
