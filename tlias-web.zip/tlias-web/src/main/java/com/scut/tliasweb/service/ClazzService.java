package com.scut.tliasweb.service;

import com.scut.tliasweb.pojo.Clazz;
import com.scut.tliasweb.pojo.PageResult;

import java.util.List;

public interface ClazzService {
    PageResult<Clazz> pageQuery(int page, int pageSize);

    void delete(Integer id);

    void add(Clazz clazz);

    Clazz getById(Integer id);

    void update(Clazz clazz);

    List<Clazz> getAll();
}
