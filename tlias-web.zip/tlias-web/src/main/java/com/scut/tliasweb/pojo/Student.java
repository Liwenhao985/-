package com.scut.tliasweb.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Student {
    private Integer id; // 主键ID
    private String name; // 姓名
    private String no; // 学号
    private String gender; // 性别
    private String phone; // 手机号
    private Integer degree; // 学历
    private String idCard; // 身份证号
    private Integer isCollege; // 是否在校 (1=是, 0=否)
    private String address; // 地址
    private LocalDate graduationDate; // 毕业时间
    private Integer violationCount; // 违纪次数
    private Integer violationScore; // 违纪扣分
    private Integer clazzId; // 班级ID
    private String clazzName; // 班级名称
    private LocalDateTime createTime; // 创建时间
    private LocalDateTime updateTime; // 更新时间
}