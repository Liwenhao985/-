package com.scut.tliasweb.mapper;

import com.scut.tliasweb.pojo.Emp;
import com.scut.tliasweb.pojo.LoginInfo;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface EmpMapper {
    @Select( "select e.* , d.name deptName from emp e left join dept d on e.dept_id=d.id order by e.id")
    List<Emp> pageQuery();

    void delete(Integer[] ids);

    @Options(useGeneratedKeys = true,keyProperty = "id")
    @Insert(  "insert into emp(username,name,gender,image,job,entry_date,dept_id,salary,dept_name,create_time,update_time) " +
            "values(#{userName},#{name},#{gender},#{image},#{job},#{entryDate},#{deptId},#{salary},#{deptName},now(),now())")
    void add(Emp emp);

    @Select( "select * from emp where id = #{id}")
    Emp getById(Integer id);

    @Update( "update emp set username = #{userName},name = #{name},gender = #{gender},image = #{image},job = #{job},entry_date = #{entryDate}," +
            "dept_id = #{deptId},salary = #{salary},dept_name = #{deptName},create_time=#{createTime},update_time = #{updateTime} where id = #{id}")
    void update(Emp emp);

    @Select( "select * from emp")
    List<Emp> getAll();

    @Select( "select id,username,name from emp where username = #{username} and password = #{password}")
    Emp login(String username, String password);
}
