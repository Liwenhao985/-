package com.scut.tliasweb.mapper;

import com.scut.tliasweb.pojo.Student;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

@Mapper
public interface StudentMapper {
    @Select("select * from students")
    List<Student> pageQuery();

    void delete(Integer[] ids);

    @Insert("insert students(name,no,gender,phone,degree,id_card,is_College,address,graduation_date,clazz_id,clazz_name,create_time,update_time)"+
            "values(#{name},#{no},#{gender},#{phone},#{degree},#{idCard},#{isCollege},#{address},#{graduationDate},#{clazzId},#{clazzName},now(),now())")
    void add(Student student);

    @Select("select * from students where id=#{id}")
    Student getById(Integer id);

    void update(Student student);
}
