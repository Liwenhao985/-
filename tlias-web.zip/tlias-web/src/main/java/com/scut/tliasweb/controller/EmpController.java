package com.scut.tliasweb.controller;

import com.scut.tliasweb.anno.OperateLog;
import com.scut.tliasweb.pojo.Emp;
import com.scut.tliasweb.pojo.Result;
import com.scut.tliasweb.service.EmpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RequestMapping( "/emps")
@RestController
public class EmpController {

    @Autowired
    private EmpService empService;

    //  分页查询
    @GetMapping
    public Result pageQuery(int page,int  pageSize) {
        return Result.success(empService.pageQuery(page,pageSize));
    }

    // 批量删除员工信息
    @OperateLog
    @DeleteMapping
     public Result delete(Integer[] ids) {
        empService.delete(ids);
        return Result.success();
    }

    //  添加员工信息
    @OperateLog
    @PostMapping
    public Result add(@RequestBody Emp emp) {
        empService.add(emp);
        return Result.success();
    }

    //  查询员工信息
    @GetMapping("/{id}")
    public Result get(@PathVariable Integer id) {
        return Result.success(empService.getById(id));
    }

    //  更新员工信息
    @OperateLog
    @PutMapping
    public Result update(@RequestBody Emp emp) {
        empService.update(emp);
        return Result.success();
    }

    //  查询所有员工信息
    @GetMapping("/list")
    public Result getAll(){
        return Result.success(empService.getAll());
    }
}
