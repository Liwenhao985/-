package com.scut.tliasweb.utils;

import com.scut.tliasweb.pojo.Result;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler
    public Result doException(Exception ex) {
        ex.printStackTrace();
        return Result.error("服务器故障，请联系管理员");
    }

    /**
     * 违反唯一约束，处理数据重复异常
     * @param ex
     * @return
     */
    @ExceptionHandler
    public Result handleDuplicateKeyException(DuplicateKeyException ex) {
        String message=ex.getMessage();
        int i=message.indexOf("Duplicate entry");
        String errMsg=message.substring(i);
        String[] arr=errMsg.split(" ");
        return Result.error(arr[2]+"已存在");
    }
}
