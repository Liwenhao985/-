package com.scut.tliasweb.controller;

import com.scut.tliasweb.pojo.Emp;
import com.scut.tliasweb.pojo.LoginInfo;
import com.scut.tliasweb.pojo.Result;
import com.scut.tliasweb.service.EmpService;
import com.scut.tliasweb.utils.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RequestMapping( "/login")
@RestController
public class LoginController {

    @Autowired
    private EmpService empService;

    @PostMapping
    public Result login(@RequestBody Emp emp) {
        Emp e=empService.login(emp.getUserName(), emp.getPassword());
        //b把loginInfo数据封装进Map
        Map<String, Object> claims = new HashMap<>();
        claims.put("id", e.getId());
        claims.put("username", e.getUserName());
        claims.put("name", e.getName());
        //获取token
        String token = JwtUtil.createToken(claims);

        return Result.success(new LoginInfo(e.getId(), e.getUserName(), e.getName(), token));
    }
}
