package com.scut.tliasweb.utils;

import io.jsonwebtoken.Claims;
import lombok.Getter;
import org.springframework.stereotype.Component;

//存储JWT解析后的用户信息
@Component
public class ThreadLocalUtil {

    private static final ThreadLocal<Claims> threadLocal = new ThreadLocal<>();

    public static void set(Claims claims) {
        threadLocal.set(claims);
    }

    public static Claims get() {
        return threadLocal.get();
    }

    public static void remove() {
        threadLocal.remove();
    }

}