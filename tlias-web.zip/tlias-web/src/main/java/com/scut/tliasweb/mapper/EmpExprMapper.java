package com.scut.tliasweb.mapper;

import com.scut.tliasweb.pojo.EmpExpr;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface EmpExprMapper {
    void delete(Integer[] ids);

    void add(List<EmpExpr> exprList);

    @Select(  "select * from emp_expr where emp_id = #{id}")
    List<EmpExpr> getById(Integer id);
}
