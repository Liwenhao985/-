package com.scut.tliasweb.service;

import com.scut.tliasweb.pojo.Dept;

import java.util.List;

public interface DeptService {
    List<Dept> getAll();

    void delete(Integer id);

    void add(String name);

    Dept getById(Integer id);

    void update(Dept dept);
}
