package com.scut.tliasweb.controller;

import com.scut.tliasweb.pojo.Result;
import com.scut.tliasweb.utils.AliyunOSSOperator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@RequestMapping( "/upload")
@RestController
public class UploadController {

    @Autowired
    private AliyunOSSOperator aliyunOSSOperator;

    @PostMapping
    public Result upload(MultipartFile file) throws Exception {
        //将文件上传到阿里云OSS
        String url =aliyunOSSOperator.upload(file.getOriginalFilename(), file.getBytes());
        return Result.success(url);
    }
}
