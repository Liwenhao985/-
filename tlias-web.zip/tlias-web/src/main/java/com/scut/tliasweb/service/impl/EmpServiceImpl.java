package com.scut.tliasweb.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.scut.tliasweb.mapper.EmpExprMapper;
import com.scut.tliasweb.mapper.EmpMapper;
import com.scut.tliasweb.pojo.Emp;
import com.scut.tliasweb.pojo.LoginInfo;
import com.scut.tliasweb.pojo.PageResult;
import com.scut.tliasweb.service.EmpService;
import com.scut.tliasweb.utils.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class EmpServiceImpl implements EmpService {
    @Autowired
    private EmpMapper empMapper;
    @Autowired
    private EmpExprMapper empExprMapper;

    @Override
    public PageResult<Emp> pageQuery(int page, int pageSize) {
        //1.设置分页参数
        PageHelper.startPage(page, pageSize);
        //2.执行查询
        List<Emp> empList = empMapper.pageQuery();
        //3.解析查询结果
        Page<Emp> p=(Page<Emp>) empList;

        return new PageResult<Emp>(p.getTotal(), p.getResult());
    }

    @Override
    public void deleteExpr(Integer[] ids) {
        empExprMapper.delete(ids);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void delete(Integer[] ids) {
        empMapper.delete(ids);
        empExprMapper.delete(ids);
    }


    @Transactional(rollbackFor = Exception.class)
    @Override
    public void add(Emp emp) {
        empMapper.add(emp);
        emp.getExprList().forEach(expr -> expr.setEmpId(emp.getId()));
        empExprMapper.add(emp.getExprList());
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public Emp getById(Integer id) {
        Emp emp = empMapper.getById(id);
        emp.setExprList(empExprMapper.getById(id));
        return emp;
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void update(Emp emp) {
        empMapper.update(emp);
        empExprMapper.delete(new Integer[]{emp.getId()});
        empExprMapper.add(emp.getExprList());
    }

    @Override
    public List<Emp> getAll() {
        return empMapper.getAll();
    }

    @Override
    public Emp login(String username, String password) {
        return empMapper.login(username, password);
    }
}
