package com.scut.tliasweb.configuration;

import com.scut.tliasweb.utils.InterceptorUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Autowired
    private InterceptorUtil interceptorUtil;

    @Override
    public void addInterceptors(org.springframework.web.servlet.config.annotation.InterceptorRegistry registry) {
        registry.addInterceptor(interceptorUtil).addPathPatterns("/**").excludePathPatterns("/login","/register");
    }
}
