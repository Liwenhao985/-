package com.scut.tliasweb.controller;

import com.scut.tliasweb.anno.OperateLog;
import com.scut.tliasweb.pojo.Dept;
import com.scut.tliasweb.pojo.Result;
import com.scut.tliasweb.service.DeptService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("/depts")
@RestController
public class DeptController {

    @Autowired
    private DeptService deptService;

    // 查询所有部门信息
    @GetMapping
    public Result list() {
        List<Dept> depts = deptService.getAll();
        return Result.success(depts);
    }

    // 删除部门
    @OperateLog
    @DeleteMapping
    public Result delete(Integer id) {
        deptService.delete(id);
        return Result.success();
    }

    // 添加部门
    @OperateLog
    @PostMapping
    public Result add(String name) {
        deptService.add(name);
        return Result.success();
    }

    // 根据id查询部门信息
    @GetMapping("/{id}")
    public Result get(@PathVariable Integer id) {
        Dept dept = deptService.getById(id);
        return Result.success(dept);
    }

    // 修改部门信息
    @OperateLog
    @PutMapping
    public Result update(Dept dept) {
        deptService.update(dept);
        return Result.success();
    }
}
