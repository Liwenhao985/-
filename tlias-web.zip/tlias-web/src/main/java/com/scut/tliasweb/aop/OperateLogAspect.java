package com.scut.tliasweb.aop;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.scut.tliasweb.mapper.OperateLogMapper;
import com.scut.tliasweb.utils.JwtUtil;
import com.scut.tliasweb.utils.ThreadLocalUtil;
import com.scut.tliasweb.pojo.OperateLog;
import io.jsonwebtoken.Claims;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Aspect
@Component
public class OperateLogAspect {

    @Autowired
    private OperateLogMapper operateLogMapper;

    private final ObjectMapper objectMapper = new ObjectMapper();

    // 定义切点：有这个@OperateLog注解的方法要记录
    @Pointcut("@annotation(com.scut.tliasweb.anno.OperateLog)")
    public void operateLogPC() {}

    // 环绕通知：记录日志
    @Around("operateLogPC()")
    public Object doAround(ProceedingJoinPoint joinPoint) throws Throwable {
        long startTime = System.currentTimeMillis();

        // 获取目标类和方法信息
        String className = joinPoint.getTarget().getClass().getName();
        String methodName = joinPoint.getSignature().getName();

        // 获取方法参数
        Object[] args = joinPoint.getArgs();
        String methodParams = toJson(args);

        Object result = null;
        try {
            // 执行原始方法
            result = joinPoint.proceed();
        } finally {
            long costTime = System.currentTimeMillis() - startTime;

            // 构建日志对象
            OperateLog log = new OperateLog();
            log.setClassName(className);
            log.setMethodName(methodName);
            log.setMethodParams(methodParams);
            log.setReturnValue(toJson(result));
            log.setCostTime(costTime);
            log.setOperateTime(LocalDateTime.now());

            // 获取当前登录用户ID（假设从 ThreadLocal 或 JWT 中获取）
            Integer empId = getCurrentUserId();
            log.setOperateEmpId(empId);

            // 保存日志
            operateLogMapper.add(log);
        }

        return result;
    }

    // 将对象转为 JSON 字符串（防止参数过长或循环引用）
    private String toJson(Object obj) {
        try {
            return objectMapper.writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            return obj != null ? obj.toString() : "void";
        }
    }

    // 从ThreadLocal中获取当前登录员工ID
    private Integer getCurrentUserId() {
        // 示例：从 ThreadLocal 获取当前用户信息
        Claims claims = ThreadLocalUtil.get();
        if (claims != null) {
            return Integer.valueOf(claims.get("id").toString());
        }
        // 默认匿名用户或未登录处理
        return 0;
    }
}