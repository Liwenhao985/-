package com.scut.tliasweb.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

//  班级
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Clazz {
    private Integer id;
    private String name;
    private String room;
    private LocalDate  beginDate;
    private LocalDate  endDate;
    private Integer masterId;
    private String masterName;
    private String status;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;
}
