package com.scut.tliasweb.service.impl;

import com.scut.tliasweb.mapper.DeptMapper;
import com.scut.tliasweb.pojo.Dept;
import com.scut.tliasweb.service.DeptService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DeptServiceImpl implements DeptService {
    @Autowired
     private DeptMapper deptMapper;

    @Override
    public List<Dept> getAll() {
         return deptMapper.getAll();
    }

    @Override
    public void delete(Integer id) {
        deptMapper.delete(id);
    }

    @Override
    public void add(String name) {
         deptMapper.add(name);
    }

    @Override
    public Dept getById(Integer id) {
        return deptMapper.getById(id);
    }

    @Override
    public void update(Dept dept) {
        deptMapper.update(dept);
    }
}
