package com.scut.tliasweb.service;

import com.scut.tliasweb.pojo.PageResult;
import com.scut.tliasweb.pojo.Student;


public interface StudentService {
    PageResult<Student> pageQuery(int page, int pageSize);

    void delete(Integer[] ids);

    void add(Student student);

    Student getById(Integer id);

    void update(Student student);

    void updateViolation(Integer id, Integer score);
}
