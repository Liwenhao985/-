package com.scut.tliasweb.utils;

import com.aliyun.oss.*;
import com.aliyun.oss.common.auth.CredentialsProviderFactory;
import com.aliyun.oss.common.auth.EnvironmentVariableCredentialsProvider;
import com.aliyun.oss.common.comm.SignVersion;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

@Component
public class AliyunOSSOperator {

    @Autowired
    private AliyunOSSProperties aliyunOSSProperties;

    public String upload(String originalFileName, byte[] content) throws Exception {
        String endpoint = aliyunOSSProperties.getEndpoint();
        String bucketName = aliyunOSSProperties.getBucketName();
        String region = aliyunOSSProperties.getRegion();

        // 从环境变量中获取访问凭证。运行本代码示例之前，请先配置环境变量
        EnvironmentVariableCredentialsProvider credentialsProvider =
                CredentialsProviderFactory.newEnvironmentVariableCredentialsProvider();

        //填写Object的完整路径，完整路径中不能包含Bucket名称，例如202506/1.jpg
        //获取当前系统日期的字符串，指定格式 yyyy/MM
        String dateStr= LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy/MM"));
        //生成一个新的且不重复的文件名
        String newFileName = UUID.randomUUID()+originalFileName.substring(originalFileName.lastIndexOf("."));
        String objectName = dateStr+"/"+newFileName;

        // 创建OSSClient实例。
        // 当OSSClient实例不再使用时，调用shutdown方法以释放资源。
        ClientBuilderConfiguration clientBuilderConfiguration = new ClientBuilderConfiguration();
        // 显式声明使用 V4 签名算法
        clientBuilderConfiguration.setSignatureVersion(SignVersion.V4);
        OSS ossClient = OSSClientBuilder.create()
                .endpoint(endpoint)
                .credentialsProvider(credentialsProvider)
                .region(region)
                .build();
        try {
            // 上传文件
            ossClient.putObject(bucketName, objectName, new ByteArrayInputStream(content));
            System.out.println("文件 " + objectName + " 上传成功。");
        } finally {
            if (ossClient != null) {
                ossClient.shutdown();
            }
        }

        return "https://"+bucketName+"."+endpoint.split("//")[1]+"/"+objectName;
    }
}
