package com.scut.tliasweb.service;

import com.scut.tliasweb.pojo.Emp;
import com.scut.tliasweb.pojo.LoginInfo;
import com.scut.tliasweb.pojo.PageResult;

import java.time.LocalDate;
import java.util.List;

public interface EmpService {
    PageResult<Emp> pageQuery(int page, int pageSize);

    void delete(Integer[] ids);

    void add(Emp emp);

    void deleteExpr(Integer[] ids);

    Emp getById(Integer id);

    void update(Emp emp);

    List<Emp> getAll();

    Emp login(String username, String password);
}
