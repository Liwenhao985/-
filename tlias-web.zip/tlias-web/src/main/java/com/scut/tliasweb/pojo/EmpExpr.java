package com.scut.tliasweb.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

//员工工作经历
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmpExpr {
    private Integer empId;
    private String company;
    private String job;
    private LocalDate begin;
    private LocalDate end;
}
