package com.scut.tliasweb.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

//员工
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Emp {
    private  Integer id;
    private String userName;
    private String password;
    private String name;
    private String gender;
    private String image;
    private String job;
    private Integer salary;
    private LocalDate entryDate;
    private Integer deptId;
    private String deptName;
    private List<EmpExpr> exprList;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;
}
