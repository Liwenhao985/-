package com.scut.tliasweb.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.scut.tliasweb.mapper.StudentMapper;
import com.scut.tliasweb.pojo.PageResult;
import com.scut.tliasweb.pojo.Student;
import com.scut.tliasweb.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    private StudentMapper studentMapper;

    @Override
    public PageResult<Student> pageQuery(int page, int pageSize) {
        PageHelper.startPage(page, pageSize);
        List<Student> studentList = studentMapper.pageQuery();
        Page<Student> p=(Page<Student>) studentList;
        return new PageResult<Student>(p.getTotal(), p.getResult());
    }

    @Override
    public void delete(Integer[] ids) {
        studentMapper.delete(ids);
    }

    @Override
    public void add(Student student) {
        studentMapper.add(student);
    }

    @Override
    public Student getById(Integer id) {
        return studentMapper.getById(id);
    }

    @Override
    public void update(Student student) {
        studentMapper.update(student);
    }

    @Override
    public void updateViolation(Integer id, Integer score) {
        Student student = studentMapper.getById(id);
        student.setViolationScore(student.getViolationScore()+score);
        student.setViolationCount(student.getViolationCount()+1);
        studentMapper.update(student);
    }
}
