package com.scut.tliasweb.mapper;

import com.scut.tliasweb.pojo.Clazz;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface ClazzMapper {
    @Select(  "select * from clazz")
    List<Clazz> pageQuery();

    @Delete( "delete from clazz where id = #{id}")
    void delete(Integer id);

    @Insert(  "insert into clazz(name,room,begin_date,end_date,master_id,master_name,status,create_time,update_time) " +
            "values(#{name},#{room},#{beginDate},#{endDate},#{masterId},#{masterName},#{status},now(),now())")
    void add(Clazz clazz);

    @Select( "select * from clazz where id = #{id}")
    Clazz getById(Integer id);

    void update(Clazz clazz);

    @Select( "select * from clazz")
    List<Clazz> getAll();
}
