package com.scut.tliasweb.controller;

import com.scut.tliasweb.anno.OperateLog;
import com.scut.tliasweb.pojo.Result;
import com.scut.tliasweb.pojo.Student;
import com.scut.tliasweb.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RequestMapping("/students")
@RestController
public class StudentController {

    @Autowired
    private StudentService studentService;

    @GetMapping
    public Result pageQuery(int page, int pageSize) {
        return Result.success(studentService.pageQuery(page, pageSize));
    }

    @OperateLog
    @DeleteMapping("/{ids}")
    public Result delete(Integer[] ids) {
        studentService.delete(ids);
        return Result.success();
    }

    @OperateLog
    @PostMapping
    public Result add(@RequestBody Student student) {
        studentService.add(student);
        return Result.success();
    }

    @GetMapping("/{id}")
    public Result getById(@PathVariable Integer id) {
        return Result.success(studentService.getById(id));
    }

    @OperateLog
    @PutMapping
    public Result update(@RequestBody Student student) {
        studentService.update(student);
        return Result.success();
    }

    @OperateLog
    @PutMapping("/violation/{id}/{score}")
    public Result updateViolation(@PathVariable Integer id, @PathVariable Integer score) {
        studentService.updateViolation(id, score);
        return Result.success();
    }
}
